var _mgptl = document.location.protocol;
(function() {
	(document.createElement('IMG')).src = _mgptl + '//counter.tovarro.com/setmuidn/images/mui.gif?muidn=g15h0F5PYhz8';
})()
