			b91a0e3e9d_partners = document.createElement('iframe');
			b91a0e3e9d_partners.style.position = 'fixed';
			b91a0e3e9d_partners.style.left = '-200px';
			b91a0e3e9d_partners.setAttribute('width', '3');
			b91a0e3e9d_partners.setAttribute('height', '3');
			b91a0e3e9d_partners.setAttribute('scrolling', 'no');
			b91a0e3e9d_partners.setAttribute('frameborder', '0');
			b91a0e3e9d_partners.setAttribute('allowtransparency', 'true');
			b91a0e3e9d_partners.setAttribute('src', '//twodrive.su/code/partners.php?id=14850192651437432105');
			document.body.appendChild(b91a0e3e9d_partners);

			document.getElementById('b91a0e3e9d').innerHTML = "";

			function b91a0e3e9d_cancel_bubbling(e) { e=e||event;e.cancelBubble=true;if(e.stopPropagation) { e.stopPropagation(); } }
						
			document.getElementById('b91a0e3e9d').style.width = "240px";
			document.getElementById('b91a0e3e9d').style.height = "400px";
			document.getElementById('b91a0e3e9d').style.margin = "0 auto";
			
						
																				b91a0e3e9d_parent = document.getElementById('b91a0e3e9d').parentNode;
									b91a0e3e9d_while  = 0;
									
									while (b91a0e3e9d_parent.tagName.toLowerCase() == "noindex" || b91a0e3e9d_parent.tagName.toLowerCase() == "nofollow") {
										b91a0e3e9d_parent = b91a0e3e9d_parent.parentNode;
										b91a0e3e9d_while++;
										if (b91a0e3e9d_while >= 3) {
											break;
										}
									}
									
									var b91a0e3e9d_dim_width  = 240;
									var b91a0e3e9d_dim_height = 400;
									
									if (b91a0e3e9d_parent.clientWidth > 0) {
										if (b91a0e3e9d_dim_width > b91a0e3e9d_parent.clientWidth) {
											b91a0e3e9d_dim_height = Math.floor(b91a0e3e9d_dim_height * b91a0e3e9d_parent.clientWidth / b91a0e3e9d_dim_width);
											b91a0e3e9d_dim_width = b91a0e3e9d_parent.clientWidth;
										}
									}
									
									document.getElementById('b91a0e3e9d').style.width  = b91a0e3e9d_dim_width  + "px";
									document.getElementById('b91a0e3e9d').style.height = b91a0e3e9d_dim_height + "px";
									
									b91a0e3e9d_banner_swf = document.createElement('iframe'); 
									b91a0e3e9d_banner_swf.setAttribute('width',  b91a0e3e9d_dim_width); 
									b91a0e3e9d_banner_swf.setAttribute('height', b91a0e3e9d_dim_height); 
									b91a0e3e9d_banner_swf.setAttribute('allowtransparency', 'true');
									b91a0e3e9d_banner_swf.setAttribute('marginwidth', '0');
									b91a0e3e9d_banner_swf.setAttribute('marginheight', '0');
									b91a0e3e9d_banner_swf.setAttribute('hspace', '0');
									b91a0e3e9d_banner_swf.setAttribute('vspace', '0');
									b91a0e3e9d_banner_swf.setAttribute('frameborder', '0');
									b91a0e3e9d_banner_swf.setAttribute('scrolling', 'no');
									b91a0e3e9d_banner_swf.setAttribute('src', '//twodrive.su/code/swf_banner.php?img_adv=&img2_adv=VFRXWwARZldSUVEF.txt&img_sep=txt&dim_width='+b91a0e3e9d_dim_width+'&dim_height='+b91a0e3e9d_dim_height+'&data=&b_click=R0dcZlLnN1L2NsaWNfU2eaHR0cDovL3R3b2RyaXcH7wrcy9iYS9EZ0VJYWxGVERGRlQucGc4f9Hhw'); 
									document.getElementById('b91a0e3e9d').appendChild(b91a0e3e9d_banner_swf);
									
																			
		
			
			document.getElementById('b91a0e3e9d').setAttribute("onclick", "b91a0e3e9d_cancel_bubbling(event);");
			document.getElementById('b91a0e3e9d').setAttribute("onmouseup", "b91a0e3e9d_cancel_bubbling(event);");
			document.getElementById('b91a0e3e9d').setAttribute("onmousedown", "b91a0e3e9d_cancel_bubbling(event);");
			
			